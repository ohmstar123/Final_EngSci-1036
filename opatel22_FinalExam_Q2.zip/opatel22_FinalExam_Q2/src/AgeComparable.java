public abstract class AgeComparable {

    //Abstract boolean to check whose younger
    abstract boolean isYounger(Employee e);
}
