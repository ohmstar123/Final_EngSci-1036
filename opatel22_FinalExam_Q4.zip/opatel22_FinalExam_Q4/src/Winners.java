public abstract class Winners {
    //abstract method
    abstract String congratulate();
}
